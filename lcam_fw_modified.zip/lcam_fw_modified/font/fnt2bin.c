/*-------------------------------------------------*/
/* FONTX2 File to Vertical Bitmap Converter        */
/*-------------------------------------------------*/

#include <stdio.h>
#include <string.h>


unsigned char Buf[32768];


int main (int argc, char *argv[])
{
	FILE *src, *dst;
	unsigned char *p, ym, xm, d;
	int chr, x, y, yc, xb, xd, yb, yd, xf;


	if (argc != 3) {
		printf("Usage: fnt2bin <fontx file> <bin file>\n");
		return 1;
	}
	src = fopen(argv[1], "rb");
	if (!src) {
		printf("Unable to open %s\n", argv[1]);
		return 1;
	}
	fread(Buf, 1, 32768, src);
	if (memcmp(Buf, "FONTX2", 6) || Buf[16] != 0 || Buf[14] < 4 || Buf[14] > 24 || Buf[15] < 4 || Buf[15] > 24) {
		printf("Invalid FONTX2 file.\n");
		return 1;
	}
	dst = fopen(argv[2], "wb");
	if (!src) {
		printf("Unable to create %s\n", argv[2]);
		return 1;
	}

	xd = Buf[14]; yd = Buf[15];
	xb = (xd + 7) / 8; yb = (yd + 7) / 8;
	fwrite(&Buf[14], 1, 2, dst);

	for (chr = 0; chr < 256; chr++) {
		p = &Buf[17 + chr * xb * yd];
		for (y = 0; y < yd; y += 8) {
			xm = 0x80; xf = 0;
			for (x = 0; x < xd; x++) {
				for (yc = y, ym = 1, d = 0; yc < yd && ym; yc++, ym <<= 1) {
					if (p[(yc & 7) * xb + xf] & xm) d |= ym;
				}
				fwrite(&d, 1, 1, dst);
				xm >>= 1;
				if (!xm) {
					xm = 0x80;
					xf++;
				}
			}
			p += xb * 8;
		}
	}

	fclose(src);
	fclose(dst);
	printf("Ok.\n");

	return 0;
}
