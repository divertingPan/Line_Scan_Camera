/*----------------------------------------------------------------------*/
/* Portable LPCM player with FM radio    (C)ChaN, 2009                  */
/*                                                                      */
/* SH1101A OLED display control module                                  */
/*----------------------------------------------------------------------*/


#include "LPC2300.h"
#include "disp.h"


//#define OLED_CS_L()		FIO0CLR2 = 0x01	/* CS# is tied to SSEL0 */
//#define OLED_CS_H()		FIO0SET2 = 0x01
#define OLED_A0_L()		FIO0CLR2 = 0x02		/* Cmd mode */
#define OLED_A0_H()		FIO0SET2 = 0x02		/* Data mode */
#define	OLED_A0			(FIO0PIN2 & 0x02)
#define OLED_RES_L()	FIO2CLR1 = 0x02
#define OLED_RES_H()	FIO2SET1 = 0x02

#define XOFS	2	/* Column offset between VRAM and OLED panel */


IMPORT_BIN_PART("font/Font6x8s.bin",  0, 2+6*128,  FontSmall);
IMPORT_BIN_PART("font/Font8x16s.bin", 0, 2+16*128, FontLarge);


static
BYTE LocX, LocY, *ImgBuff;
static
const BYTE *Font;



/*-----------------------------------------*/
/* Send a byte command to the OLED module  */

void oled_cmd (
	BYTE d
)
{
	if (OLED_A0) {
		while (SSP0SR & 0x10) ;
		OLED_A0_L();		/* A0=L */
	}
	while (!(SSP0SR & 0x02)) ;
	SSP0DR = d;
}




/*-----------------------------------------*/
/* Send a byte data to the OLED module     */

void oled_data (
	BYTE d
)
{
	if (!OLED_A0) {
		while (SSP0SR & 0x10) ;
		OLED_A0_H();		/* A0=H */
	}
	while (!(SSP0SR & 0x02)) ;
	SSP0DR = d;
}




/*-----------------------------------------*/
/* Clear OLED                              */

void disp_cls (void)
{
	BYTE x, y;

	/* Clear all */
	for (y = 0xB0; y < 0xB8; y++) {
		oled_cmd(y);
		oled_cmd(XOFS);
		oled_cmd(0x10);
		for (x = 0; x < OLED_X; x++)
			oled_data(0);
	}

	LocX = LocY = 0;
}




/*-----------------------------------------*/
/* Put a bit image to the OLED             */

void disp_xfer_image (
	const BYTE* src,	/* Pointer to the source bitmap */
	BYTE src_x,			/* X size of the source bitmap (dots) */
	BYTE src_y,			/* Y size of the source bitmap (8 dots) */
	BYTE pos_x,			/* X position on the OLED (dots) */
	BYTE pos_y			/* Y position on the OLED (x8 dots) */
)
{
	BYTE xc;


	pos_x += XOFS;
	do {
		oled_cmd(0xB0 | pos_y);			/* Set page addres */
		oled_cmd(0x10 | (pos_x >> 4));	/* Set column address */
		oled_cmd(pos_x & 0x0F);
		xc = src_x;		/* Image width */
		do
			oled_data(*src++);
		while (--xc);
		pos_y++;		/* Next page */
	} while (--src_y);	/* Repeat src_y */
}




/*-----------------------------------------*/
/* Put a bit image to the buffer           */

void disp_draw_image (
	const BYTE* src,	/* Pointer to the source bitmap */
	BYTE src_x,			/* X size of the source bitmap (dots) */
	BYTE src_y,			/* Y size of the source bitmap (8 dots) */
	BYTE* buff			/* Left-Top address of the destination buffer */
)
{
	BYTE xc;


	do {
		xc = src_x;		/* Image width */
		do
			*buff++ = *src++;
		while (--xc);
		buff += OLED_X - src_x;
	} while (--src_y);	/* Repeat src_y rows */
}




/*-----------------------------------------*/
/* Set cursor location, font and buffer    */

void disp_locate (
	WORD loc,			/* Cursor location (y * 256 + x) */
	const BYTE* font,	/* Pointer to the font table */
	BYTE* imgbuff		/* Virtual image buffer (NULL:destination is OLED) */
)
{
	LocX = (BYTE)loc;
	LocY = (BYTE)(loc >> 8);
	Font = font;
	ImgBuff = imgbuff;
}




/*-----------------------------------------*/
/* Put a battery indicator (14x8)          */

void disp_put_bat (
	UINT lv				/* Battery level (0-5) */
)
{
	static const BYTE bat[6][14] = {
		{0x3C,0xE7,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0xFF},
		{0x3C,0xE7,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0xBD,0x81,0xFF},
		{0x3C,0xE7,0x81,0x81,0x81,0x81,0x81,0x81,0x81,0xBD,0x81,0xBD,0x81,0xFF},
		{0x3C,0xE7,0x81,0x81,0x81,0x81,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xFF},
		{0x3C,0xE7,0x81,0x81,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xFF},
		{0x3C,0xE7,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xBD,0x81,0xFF}
	};


	if (lv > 5) lv = 5;
	if (ImgBuff)
		disp_draw_image(bat[lv], 14, 1, &ImgBuff[LocY * OLED_X + LocX]);
	else
		disp_xfer_image(bat[lv], 14, 1, OLED_X - 14, 0);
}




/*-----------------------------------------*/
/* Put a char to the OLED or image buff    */


void disp_putc (
	unsigned char c
)
{
	BYTE x, y, xs, ys;


	x = LocX; y = LocY;

	if (c == '\r' || y >= 8) {
		x = 0;
	} else {
		xs = Font[0]; ys = (Font[1] + 7) / 8;
		if (x > OLED_X - xs || c == '\n') {
			x = 0; y += ys;
		}
		if (c <= 0x7E && c != '\n') {
			if (ImgBuff)
				disp_draw_image(&Font[2 + xs * ys * c], xs, ys, &ImgBuff[y * OLED_X + x]);
			else
				disp_xfer_image(&Font[2 + xs * ys * c], xs, ys, x, y);
			x += xs;
		}
	}

	LocX = x; LocY = y;
}




/*-----------------------------------------*/
/* Initialize OLED module                  */

void disp_init (void)
{
	UINT i;
	static const BYTE ini[] = {	/* Initialization parameters for SSD1306 */
		0xAE,//--turn off oled panel
		0x00,//--set low column address
		0x10,//--set high column address
		0x40,//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
		0x81,//--set contrast control register
		0xCF,//--Set SEG Output Current Brightness
		0xA1,//--Set SEG/Column Mapping      0xa0: horizonal reverse  0xa1: none
		0xC8,//--Set COM/Row Scan Direction  0xc0: vertical reverse   0xc8: none
		0xA6,//--set normal display
		0xA8,//--set multiplex ratio(1 to 64)
		0x3f,//--1/64 duty
		0xD3,//--set display offset	Shift Mapping RAM Counter (0x00~0x3F)
		0x00,//--not offset
		0xd5,//--set display clock divide ratio/oscillator frequency
		0x80,//--set divide ratio, Set Clock as 100 Frames/Sec
		0xD9,//--set pre-charge period
		0xF1,//--Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
		0xDA,//--set com pins hardware configuration
		0x12,
		0xDB,//--set vcomh
		0x40,//--Set VCOM Deselect Level
		0x20,//--Set Page Addressing Mode (0x00/0x01/0x02)
		0x02,//
		0x8D,//--set Charge Pump enable/disable
		0x14,//--set(0x10) disable
		0xA4,//--Disable Entire Display On (0xa4/0xa5)
		0xA6,//--Disable Inverse Display On (0xa6/a7) 
		0xAF //--turn on oled panel
	};


	FIO2DIR1 |= 0x02;	/* RES# pin */
	FIO0DIR2 |= 0x02;	/* A0 pin */

	/* Initialize SSP0 */
	SSP0CPSR = 4;		/* PCLK/4 = 4.5MHz */
	SSP0CR0 = 0x00C7;	/* 8-bit, SPI mode 3 */
	SSP0CR1 = 0x02;		/* Enable SSP0 */
	PINSEL0 = (PINSEL0 & ~(3<<30)) | (2<<30);	/* Attach SCK0 to I/O pad */
	PINSEL1 = (PINSEL1 & ~(3<<0)) | (2<<0);		/* Attach SSEL0 to I/O pad */
	PINSEL1 = (PINSEL1 & ~(3<<4)) | (2<<4);		/* Attach MOSI0 to I/O pad */

	OLED_RES_L();	/* RESET=L */
	for (i = 0; i < 1000; i++) FIO0PIN;
	OLED_RES_H();;	/* RESET=H */
	for (i = 0; i < 1000; i++) FIO0PIN;

	/* Initialize OLED module */
	for (i = 0; i < sizeof ini; i++)
		oled_cmd(ini[i]);

	disp_cls();			/* Clear display RAM */

	oled_cmd(0xAF);		/* Display ON */
}


