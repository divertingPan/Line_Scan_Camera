/*--------------------------------------------------------------------------*/
/* Line Scam Camera - Main Module                            (C)ChaN, 2010  */
/*--------------------------------------------------------------------------*/
/* Copyright (C) 2010, ChaN, all right reserved.
/  This program is a free software and there is NO WARRANTY.
/  No restriction on use. You can use, modify and redistribute it for
/  personal, non-profit or commercial products UNDER YOUR RESPONSIBILITY.
/  Redistributions of source code must retain the above copyright notice.
/---------------------------------------------------------------------------*/

#include <string.h>
#include "LPC2300.h"
#include "integer.h"
#include "interrupt.h"
#include "disp.h"
#include "uart.h"
#include "ff.h"
#include "xprintf.h"
#include "diskio.h"
#include "lcam.h"


extern void terminal (void);


BYTE Buff[SZ_CAPT] __attribute__ ((section(".sram"), aligned (4)));		/* Working buffer */

volatile BYTE CaptStat;
volatile INT CaptOfs;

volatile BYTE Btn[2], BtnCmd[2];		/* Button scan contorls */
volatile BYTE BtLevel, Lbt, Ovt, Ovf;	/* Battery monitor, Overrun indicator timer */
volatile UINT Timer;		/* 1kHz increment timer */

PARMS Parms;

FATFS Fatfs;
FIL File1;
DWORD Lmt[32];



/*---------------------------------------------------------*/
/* User provided call-back functions                       */
/*---------------------------------------------------------*/


DWORD get_fattime (void)	/* Called from ff.c */
{
	return 0;
}



void InitializeEMC (void)	/* Called from asmfunc.S prior to all start-up code */
{
#define PLL_N		8UL		/* pllclkin[MHz] / 2 */
#define PLL_M		72UL
#define CCLK_DIV	4

	MAMCR = 0;				/* Configure MAM for 72MHz operation */
	MAMTIM = 3;
	MAMCR = 2;

	if ( PLLSTAT & (1 << 25) ) {	/* Disconnect PLL output if PLL is in use */
		PLLCON = 1;
		PLLFEED = 0xAA; PLLFEED = 0x55;
	}
	PLLCON = 0;				/* Disable PLL */
	PLLFEED = 0xAA; PLLFEED = 0x55;

	SCS |= 0x30;			/* Enable main oscillator (16MHz) */
	while (!(SCS & 0x40)) ;	/* Wait for oscillation stable */
	CLKSRCSEL = 1;			/* Select main oscillator as PLL input clock */

	PLLCFG = ((PLL_N - 1) << 16) | (PLL_M - 1);	/* Configure PLL for 72MHz operation */
	PLLFEED = 0xAA; PLLFEED = 0x55;

	PLLCON = 1;				/* Enable PLL */
	PLLFEED = 0xAA; PLLFEED = 0x55;
	while ((PLLSTAT & (1 << 26)) == 0);	/* Wait for PLL lock */
	CCLKCFG = CCLK_DIV-1;	/* Select CCLK frequency (divide ratio of hclk) */

	PLLCON = 3;				/* Connect PLL output to the sysclk */
	PLLFEED = 0xAA; PLLFEED = 0x55;
}




/*---------------------------------------------------------*/
/* 1kHz Interval Timer                                     */
/*---------------------------------------------------------*/

void scan_inputs (void)
{
	BYTE d, k;
	static BYTE lbtmr, ktmr, mvt;
	static WORD mv;


	d = Btn[1];
	Btn[1] = ~FIO2PIN0 & 0x3F;
	if (Btn[1] == d) {
		d = Btn[0];
		Btn[0] = Btn[1];
		d = (d ^ Btn[0]) & Btn[0];
		if (d) ktmr = 125;
		if (ktmr) {
			ktmr--;
		} else {
			if (Btn[0] & 0x06) {
				d = Btn[0];
				ktmr = 25;
			}
		}
		if (d) {
			k = K_POWER;
			if (d & 0x01) k = K_LEFT;
			if (d & 0x02) k = K_DOWN;
			if (d & 0x04) k = K_UP;
			if (d & 0x08) k = K_ENTER;
			if (d & 0x10) k = K_RIGHT;
			BtnCmd[1] = k;
			BtnCmd[0] = 1;
		}
	}

	d = Ovt;						/* Overrun indicator (timered) */
	if (d) Ovt = d - 1;

	mv += (AD0DR1 & 0xFFFF) / 10;	/* Get battery voltage [mV] */
	AD0CR = 0x01201102;				/* Restart A-D conversion */
	if (++mvt >= 8) {
		mv /= 8;
		if (mv < LB_LEVEL) {
			if (++lbtmr >= 25) {
				BtnCmd[1] = 0;
				BtnCmd[0] = 1;
				Lbt = 1;
			}
		} else {
			lbtmr = 0;
			BtLevel = (BYTE)((mv - LB_LEVEL) / 80);	/* Indicator: 80mV/step from LB_LEVEL */
		}
		mvt = mv = 0;
	}

}



void Isr_TIMER1 (void)
{
	static BYTE div;


	T1IR = 1;	/* Clear irq flag */

	Timer++;

	switch (++div & 3) {
	case 0:
		disk_timerproc();
		break;
	case 1:
		scan_inputs();
		break;
	default:
		break;
	}
}



/*---------------------------------------------------------*/
/* CCD end of line interrupt (Falling edge on P0.10)       */
/*---------------------------------------------------------*/

void Isr_Line (void)
{
	DWORD freg[4], wi;


	IO0_INT_CLR = (1<<10);	/* Clear IRQ flag */

	StoreFiqRegsSv((long*)freg);	/* Get FIQ shadow regs R8-R11 */
	wi = freg[2] - (DWORD)Buff;		/* Write index of capture buffer */

	switch (CaptStat) {
	case START_REC:	/* Start request for record */
	case START_MON:	/* Start request for monitor */
		FIO0SET0 = 0x02;		/* Disable FIQ */
		/* Initialize FIQ shadow regs */
		freg[0] = (DWORD)&FIO0DIR;	/* R8: FIO regs base address */
		freg[1] = (DWORD)&EXTINT;	/* R9: EXTINT reg address */
		freg[2] = (DWORD)Buff;		/* R10: Data write pointer */
		freg[3] = 1;				/* R11: Clock pattern */
		LoadFiqRegsSv((long*)freg);

		CaptOfs = -1;			/* Clear data ready flag */
		CaptStat += 2;			/* Running state */
		FIO0CLR0 = 0x02;		/* Enable FIQ */
		break;

	case RECORDING:		/* Recording */
		if (wi % SZ_LINE) {		/* Overrun occured? */
			FIO0SET0 = 0x02;	/* Disable FIQ */
			CaptStat = 0;		/* Stop with error */
		} else {
			if (!(wi % (SZ_CAPT / 2))) {
				if (CaptOfs != -1) {	/* Overrun occured? */
					wi -= SZ_LINE;	/* Discard this line */
					Ovt = 100;		/* Set overrun flag */
					Ovf = 1;
				} else {
					CaptOfs = wi - SZ_CAPT / 2;	/* Inform that a block of lines arrived */
					Ovf = 0;
				}
				freg[2] = (wi % SZ_CAPT) + (DWORD)Buff;	/* Next write index */
				LoadFiqRegsSv((long*)freg);
			}
		}
		break;

	case MONITORING:	/* Monitoring */
		if (wi % SZ_LINE) {		/* Overrun occured? */
			FIO0SET0 = 0x02;	/* Disable FIQ */
			CaptStat = 0;		/* Stop with error */
		} else {
			if (!(wi % (SZ_MON / 2))) {
				if (CaptOfs != -1) {	/* Overrun occured? */
					wi -= SZ_LINE;		/* Discard this line */
				} else {
					CaptOfs = wi - SZ_MON / 2;	/* Inform that a block of lines arrived */
				}
				freg[2] = (wi % SZ_MON) + (DWORD)Buff;	/* Next write index */
				LoadFiqRegsSv((long*)freg);
			}
		}
		break;

	default:	/* Idle(0) or Stop Request(9) */
		FIO0SET0 = 0x02;	/* Disable FIQ */
		CaptStat = 0;		/* Stop */
		break;
	}
}




/*---------------------------------------------------------*/
/* Line captureing control functions                       */
/*---------------------------------------------------------*/


void ccd_gain (
	int gain	/* CCD amplifier gain in unit of dB (0-26) */
)
{
	if (gain < 0) gain = 0;		/* Clip between 0 to 26 */
	if (gain > 26) gain = 26;
	Parms.gain = gain;
	gain *= 2560;
	DACR = (gain > 65535) ? 65535 : gain;
}



void ccd_speed (
	int div		/* Clock divide ratio (PM#[MHz] = 72 / div) */
)
{
	if (div < 16) div = 16;		/* Clip between 16 to 72 */
	if (div > 72) div = 72;
	Parms.speed = div;
	PWM1MR0 = (DWORD)div;
	PWM1MR2 = (DWORD)div / 2;
	PWM1LER = 5;
}



void capt_control (
	BYTE md		/* 1:Start capture, 2:Start monitor, 9:Stop */
)
{
	CaptStat = md;
	while (CaptStat == md) ;
}




/*---------------------------------------------------------*/
/* Display control function                                */
/*---------------------------------------------------------*/

void draw_roll_m (
	const BYTE* line,	/* Source line (SZ_LINE dots x 8 lines) */
	BYTE* diff,			/* Error diffusion buffer */
	BYTE* imgbuff		/* Screen image buffer (128 dots x 64 lines in OLED memory form) */
)
{
	UINT x, i, j, v, w;
	BYTE *d;
	const BYTE *b;


	/* Roll-up a line of the screen image  */
	for (x = 0; x < OLED_X; x++) {
		d = &imgbuff[x + OLED_X * (MI_Y / 8 - 1)];
		for (i = w = 0; i < MI_Y / 8; i++) {
			v = *d;
			*d = (w | v) >> 1;
			w = v << 8;
			d -= OLED_X;
		}
	}

	/* Generate a line and put it bottom of the screen image */
	for (x = 0; x < OLED_X; x++) {
		v = 0; b = line;
		for (i = 0; i < SZ_LINE / OLED_X; i++) {
			for (j = 0; j < SZ_LINE / OLED_X; j++)
				v += *b++;
			b += SZ_LINE - SZ_LINE / OLED_X;
		}
		v /= (SZ_LINE / OLED_X) * (SZ_LINE / OLED_X);
		if (v < 64) v = 64;
		if (v > 191) v = 191;
		v = v * 2 - 128 + diff[x];
		if (v >= 254) {
			v -= 254;
			imgbuff[x + OLED_X * (MI_Y / 8 - 1)] |= 0x80;
		}
		diff[x] = v;
		line += SZ_LINE / OLED_X;
	}
}



void draw_scope_m (
	const BYTE* line,	/* Source line (SZ_LINE dots) */
	BYTE* imgbuff		/* Screen image buffer (128 dots x 32 lines in OLED memory form) */
)
{
	UINT v, t, b, x, y, i, max, min;
	BYTE *d;


	for (x = 0; x < OLED_X; x++) {
		max = 0; min = 255;
		for (i = 0; i < SZ_LINE / OLED_X; i++) {
			v = *line++;
			if (max < v) max = v;
			if (min > v) min = v;
		}
		max /= 256 / SC_Y;
		min /= 256 / SC_Y;
		d = imgbuff; t = SC_Y - 1; b = SC_Y - 8;
		for (y = 0; y < SC_Y; y += 8) {
			v = 0;
			if (max >= b && min <= t) {
				v = 0xFF;
				if (max < t) v <<= t - max;
				if (min > b) v &= 0xFF >> (min - b);
			}
			if (y == SC_Y - 8 && (x & 1)) v |= 0x80;
			*d = v;
			d += OLED_X; t -= 8; b -= 8; 
		}
		imgbuff++;
	}
}



void draw_focus_m (
	const BYTE* line,	/* Source line (SZ_LINE dots) */
	BYTE* imgbuff		/* Screen image buffer (128 dots x 32 lines in OLED memory form) */
)
{
	UINT v, w, b, x, y, i, max;
	INT dif;
	BYTE *d;


	w = *line;
	for (x = 0; x < OLED_X; x++) {
		for (i = max = 0; i < SZ_LINE / OLED_X; i++) {
			v = *line++;
			dif = (INT)v - (INT)w;
			if (dif < 0) dif = 0 - dif;
			if (max < (UINT)dif) max = dif;
			w = v;
		}
		max /= 256 / FC_Y / 2;
		d = imgbuff; b = FC_Y - 8;
		for (y = 0; y < FC_Y; y += 8) {
			v = 0;
			if (max >= b) {
				v = 0xFF;
				if (max < b + 8) v <<= b + 8 - max;
			}
			*d = v;
			d += OLED_X; b -= 8; 
		}
		imgbuff++;
	}
}




/*---------------------------------------------------------*/
/* Camera control functions                                */
/*---------------------------------------------------------*/

BYTE display (void)
{
	BYTE k, v;
	UINT i, agc = 0;


	for (i = 0; i < OLED_X * OLED_Y / 8; Buff[SZ_MON + i++] = 0) ;

	capt_control(START_MON);

	for (;;) {
		if (uart0_test()) {
			k = uart0_get();
			switch (k) {
			case K_UP:
				if (Parms.mode & 1)
					ccd_speed(Parms.speed - 1);
				else
					ccd_gain(Parms.gain + 1);
				break;
			case K_DOWN:
				if (Parms.mode & 1)
					ccd_speed(Parms.speed + 1);
				else
					ccd_gain(Parms.gain - 1);
				break;
			case K_RIGHT:
				Parms.mode ^= 1;
				for (i = 0; i < OLED_X * OLED_Y / 8; Buff[SZ_MON + i++] = 0) ;
				break;
			case K_LEFT:
				agc = 1;
				break;
			default:
				capt_control(STOP_CAPT);
				return k;
			}
		}

		if (agc && Timer >= 50) {
			for (i = v = 0; i < SZ_LINE; i++) {
				if (v < Buff[i]) v = Buff[i];
			}
			switch (agc) {
			case 1:
				if (v < 255) {
					ccd_gain(Parms.gain + 1);
					agc = 2;
				} else {
					if (Parms.gain == 0)
						agc = 0;
					else
						ccd_gain(Parms.gain - 1);
				}
				break;
			case 2:
				if (v == 255) {
					agc = 0;
				} else {
					if (Parms.gain == 26)
						agc = 0;
					else
						ccd_gain(Parms.gain + 1);
				}
				break;
			}
			Timer = 0;
		}

		if (CaptOfs != -1) {
			disp_locate(0, FontSmall, &Buff[SZ_MON]);
			if (Parms.mode & 1) {
				draw_roll_m(&Buff[CaptOfs], &Buff[SZ_MON + OLED_X * MI_Y / 8], &Buff[SZ_MON]);
				xfprintf(disp_putc, "F:%4u", 32907 / Parms.speed);
			} else {
				draw_scope_m(&Buff[CaptOfs], &Buff[SZ_MON]);
				draw_focus_m(&Buff[CaptOfs], &Buff[SZ_MON + OLED_X * FC_Y / 8]);
				xfprintf(disp_putc, "%2ddB", Parms.gain);
			}
			CaptOfs = -1;
			disp_locate(OLED_X - 14, FontSmall, &Buff[SZ_MON]);
			disp_put_bat(BtLevel);
			disp_xfer_image(&Buff[SZ_MON], OLED_X, OLED_Y / 8, 0, 0);
		}
	}
}




void capture (void)
{
	char fn[16];
	FRESULT res;
	UINT lc, bw, tm;
	DWORD scl, ssc;
	INT i;
	BITMAPFILEHEADER *bmfh;
	BITMAPINFO *bmi;


	disp_cls();
	disp_locate(0x0314, FontLarge, 0);
	xfprintf(disp_putc, "Prepare");

	do {	/* Create a numbered file */
		xsprintf(fn, "Y%04u.BMP", ++Parms.seq);
		res = f_open(&File1, fn, FA_WRITE | FA_CREATE_NEW);
	} while (res == FR_EXIST && Parms.seq < 9999);
	xprintf("%s\n", fn);

	if (res == FR_OK) {
		/* Adjust start cluster to AU boundary */
		scl = File1.fs->last_clust + 1;
		if (scl >= File1.fs->n_fatent) scl = 2;
		ssc = File1.fs->database + File1.fs->csize * (scl - 2);
		ssc = (ssc + (1 << 13) - 1) & ~((1 << 13) - 1);
		scl = (ssc - File1.fs->database) / File1.fs->csize + 1;
		File1.fs->last_clust = scl;

		/* Pre-allocate data clusters */
		res = f_lseek(&File1, SZ_LINE * MAX_LINES + 16384);
		if (res == FR_OK) {
			if (File1.fptr >= SZ_LINE * MAX_LINES / 10 + 16384) {
				File1.cltbl = Lmt; Lmt[0] = sizeof(Lmt) / sizeof(Lmt[0]);
				res = f_lseek(&File1, CREATE_LINKMAP);
				if (res == FR_OK) xputs("LMT created.\n");
				if (res == FR_NOT_ENOUGH_CORE) {
					File1.cltbl = 0;
					res = FR_OK;
				}
				res = f_lseek(&File1, 0);
			} else {	/* Not enough disk space */
				res = 99;
			}
			if (res == FR_OK)
				res = f_write(&File1, Buff, SZ_CAPT / 2, &bw);	/* Put dummy header */
		}
		if (res != FR_OK) { 
			f_close(&File1);
			f_unlink(fn);
		}
	}

	lc = 0;
	if (res == FR_OK) {
		disp_locate(0x0314, FontLarge, 0);	/* Ready message and wait for button released */
		xfprintf(disp_putc, " Ready ");
		while (Btn[0] & 0x08) ;

		disp_locate(0x0314, FontLarge, 0);	/* Start to record */
		xfprintf(disp_putc, "Record ");
		capt_control(START_REC);

		for (lc = 0; lc < MAX_LINES; )	{
			if (uart0_test()) {
				uart0_get(); break;
			}
			while ((i = CaptOfs) == -1 && CaptStat) ;
			if (i == -1) break;
			tm = Timer;
			res = f_write(&File1, &Buff[i], SZ_CAPT / 2, &bw);
			CaptOfs = -1;
			xprintf("%3u%s\n", Timer - tm, Ovf ? "*" : "");
			if (res || bw != SZ_CAPT / 2) break;
			lc += SZ_CAPT / 2 / SZ_LINE;
			if (lc & (SZ_CAPT / 2 / SZ_LINE)) {
				disp_put_bat(BtLevel);
			} else {
				disp_locate(0, FontSmall, 0);
				xfprintf(disp_putc, "%6u%c", lc, Ovt ? '*' : ' ');
			}
		}
		capt_control(STOP_CAPT);

		if (res == FR_OK) {
			File1.fs->last_clust = File1.clust;
			File1.fs->fsi_flag = 1;
			res = f_truncate(&File1);	/* Truncate unused part */
			if (res == FR_OK) {
				/* Create BMP file header */
				for (i = 0; i < 16384; Buff[i++] = 0) ;		/* Clear working buffer */
				bmfh = (BITMAPFILEHEADER*)(long)Buff;
				ST_WORD(&bmfh->bfType, 0x4D42);				/* "BM" */
				ST_DWORD(&bmfh->bfSize, SZ_LINE * lc + 16384);	/* Size of this file */
				ST_DWORD(&bmfh->bfOffBits, 16384);			/* Bitmap start offset */
				bmi = (BITMAPINFO*)(long)&Buff[sizeof(BITMAPFILEHEADER)];
				ST_DWORD(&bmi->bmiHeader.biSize, 40);		/* Header size */
				ST_DWORD(&bmi->bmiHeader.biWidth, SZ_LINE);	/* Image width */
				ST_DWORD(&bmi->bmiHeader.biHeight, lc);		/* Image height (number of captured lines) */
				ST_WORD(&bmi->bmiHeader.biPlanes, 1);
				ST_WORD(&bmi->bmiHeader.biBitCount, 8);		/* Color depth (8bit) */
				for (i = 0; i < 256; i++) {					/* Palette (grayscale) */
					bmi->bmiColors[i].rgbBlue = (BYTE)i;
					bmi->bmiColors[i].rgbGreen = (BYTE)i;
					bmi->bmiColors[i].rgbRed = (BYTE)i;
				}
				f_lseek(&File1, 0);							/* Put it to the file */
				res = f_write(&File1, Buff, 16384, &bw);
			}
		}
		f_close(&File1);
		if (res) f_unlink(fn);
	}

	disp_locate(0x0310, FontLarge, 0);
	if (res != FR_OK) {
		xfprintf(disp_putc, "FS Error:%u", res);
	} else {
		xfprintf(disp_putc, "  OK   ");
		xprintf("%u lines captured.\n", lc);
	}
	for (Timer = 0; Timer < 2000; ) ;
	if (uart0_test()) uart0_get();
}




BYTE load_parms (void)
{
	UINT n, br;
	BYTE k;
	FRESULT res;
	FATFS *fs;
	DWORD cl;
	DIR dir;
	FILINFO fno;


	for (Timer = 0; Timer < 500; ) ;			/* Delay 500ms */
	if (!(Btn[0] & 0x20) || Lbt) return RC_ESC;	/* Shutdown if low battery or power button is released within 500ms */

	disp_locate(0x0010, FontLarge, 0);			/* Display opening message */
	xfprintf(disp_putc, "LINE CAMERA\n\n");

	f_mount(0, &Fatfs);					/* Enable FAT file system */

	res = f_getfree("/", &cl, &fs);		/* Get free space on the card */
	if (res == FR_OK) {
		f_mkdir("/DCIM");				/* Create work dir (no effect if exist) */
		f_mkdir("/DCIM/LCAM");
		res = f_chdir("/DCIM/LCAM");	/* Goto work dir */
		if (res == FR_OK) {
			if (f_open(&File1, "parms.dat", FA_READ) == FR_OK) {	/* Load parameter file */
				f_read(&File1, &Parms, sizeof(Parms), &br);
				f_close(&File1);
			}
			ccd_speed(Parms.speed);
			ccd_gain(Parms.gain);
			n = 0;	/* Get number of image files */
			if (f_opendir(&dir, ".") == FR_OK) {
				while (f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
					if (strstr(fno.fname, ".BMP")) n++;
				}
			}
		}
	}
	if (res == FR_OK) {		/* Display card status message */
		xfprintf(disp_putc, " %u images\n %lu MB free", n, cl * fs->csize / 2048);
		k = RC_OK;
	} else {				/* Display fs error message */
		xfprintf(disp_putc, "FS Error: %u", res);
		k = RC_ERR;
	}

	for (Timer = 0; Timer < 1500; ) ;	/* Delay 1.5sec */
	while (Btn[0] & 0x20) ;				/* Wait while power button is pressed */
	while (uart0_test()) uart0_get();	/* Flush command buffer */

	return k;
}



void save_parms (void)
{
	UINT bw;


	disp_cls();
	disp_locate(0x0310, FontLarge, 0);
	xfprintf(disp_putc, Lbt ? "Low Battery" : " Good bye!");

	if (f_open(&File1, "parms.dat", FA_WRITE | FA_OPEN_ALWAYS) == FR_OK) {
		f_write(&File1, &Parms, sizeof(Parms), &bw);
		f_close(&File1);
	}

	for (Timer = 0; Timer < 1500; ) ;
}



void IoInit (void)
{
	ClearVector();

	SCS |= 1;				/* Enable FIO0 and FIO1 */

	FIO0PINL = 0x0802;		/* P0.11 P0.1 = H, P0.0 = L */
	FIO0DIRL = 0x0803;

	/* Enable ADC (battery monitor) */
	PINMODE1 = (PINMODE1 & ~(3<<16)) | (2<<16);	/* Disable pull-up on P0.24(AD0.1) */
	PINSEL1 = (PINSEL1 & ~(3<<16)) | (1<<16);	/* Attach AD0.1 to I/O pad */
	PCONP |= (1 << 12);		/* ADC power on */

	/* Initialize Timer1 as 1kHz interval timer */
	RegisterIrq(TIMER1_INT, Isr_TIMER1, PRI_LOWEST);
	T1CTCR = 0;
	T1MR0 = 18000 - 1;	/* 18M / 1k = 18000 */
	T1MCR = 0x3;		/* Clear TC and Interrupt on MR0 match */
	T1TCR = 1;

	/* Initialize CCD pixel clock generator (pin: PWM1.2) */
	PCONP |= (1<<6);	/* PCPWM1 = 1 */
	PWM1TCR = 0x02;		/* Stop PWM1 */
	PCLKSEL0 = (PCLKSEL0 & ~(3<<12)) | (1<<12);	/* PCLK_PWM1 = 0b01 */
	PINSEL7 |= (3<<18);							/* Attach PWM1.2 to I/O pad */
	PWM1PR = 0; PWM1PCR = 0x0400;
	PWM1MCR = 2;
	PWM1MR0 = 36; PWM1MR2 = 36 / 2;
	PWM1TCR = 0x09;		/* Start PWM1 */

	/* Initialize CCD gain control output (pin: AOUT) */
	PINMODE1 = (PINMODE1 & ~(3<<20)) | (2<<20);	/* Disable pull-up on AOUT pin */
	PINSEL1 = (PINSEL1 & ~(3<<20)) | (2<<20);	/* Attach AOUT to I/O pad */

	/* Enable CCD end of line interrupt (pin: P0.10) */
	RegisterIrq(EINT3_INT, Isr_Line, PRI_LOWEST-2);
	IO0_INT_EN_F = (1<<10);	/* Enable pin change interrupt on falling edge on P0.10 */

	/* Enable CCD data FIFO ready interrupt (pin: EINT1) */
	EXTMODE = 0x01;								/* EINT0 is triggered by falling-edge */
	PINSEL4 = (PINSEL4 & ~(3<<20)) | (1<<20);	/* Attach EINT0 to I/O pad */
	SelectFiq(EINT0_INT);						/* Select EINT0 as FIQ (fiq_handler in asmfunc.S) */
	PCLKSEL1 = (PCLKSEL1 & ~(3<<28)) | (1<<28);	/* Select PCLK for system control block, CCLK = 72MHz */

	IrqEnable();	/* Enable IRQ and FIQ */

	uart0_init();	/* Initialize UART0 driver */
	disp_init();	/* Initialize display driver */
}




/*---------------------------------------------------------*/
/* Main routine                                            */
/*---------------------------------------------------------*/

int main (void)
{
	BYTE k;


	IoInit();					/* Initialize peripherals */

	xdev_out(uart0_put);		/* Default console devices */
	xdev_in(uart0_get);

	k = load_parms();			/* Initialize system, opening message */

	if (k == RC_OK) {
		for (;;) {
			k = display();		/* Adjust gain and speed */
			if (k != K_ENTER) break;
			capture();			/* Capture an image */
		}
		if (k == K_POWER) {		/* Normal end */
			save_parms();		/* Save settings, ending message */
			return 0;			/* Shutdown */
		}
	}

	terminal();	/* Start debug terminal */

	return 0;	/* Shutdown */
}


