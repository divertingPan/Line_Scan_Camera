#define	MAX_LINES	100000	/* Number of lines to record maximum */
#define LB_LEVEL	3550	/* Shutdown voltage [mV] */


#define	SZ_LINE		1024
#define SZ_CAPT		32768
#define SZ_MON		(SZ_LINE * 8 * 2)

#define MI_Y	64		/* Rolling image Y size */
#define SC_Y	32		/* Scope Y size */
#define FC_Y	32		/* Focus Y size */

#define K_RIGHT	0x04
#define K_LEFT	0x13
#define K_UP	0x05
#define K_DOWN	0x18
#define K_ENTER	0x0D
#define K_POWER	0x00
#define RC_OK	0x80
#define RC_ESC	0x81
#define RC_ERR	0x82

#define START_REC	1
#define START_MON	2
#define	RECORDING	3
#define	MONITORING	4
#define STOP_CAPT	9


typedef struct {
	int gain;
	int speed;
	int mode;
	int seq;
} PARMS;


typedef struct {
	WORD	bfType;
	DWORD   bfSize;
	WORD	bfReserved1;
	WORD	bfReserved2;
	DWORD   bfOffBits;
} __attribute__ ((packed)) BITMAPFILEHEADER;

typedef struct {
	DWORD  biSize;
	LONG   biWidth;
	LONG   biHeight;
	WORD   biPlanes;
	WORD   biBitCount;
	DWORD  biCompression;
	DWORD  biSizeImage;
	LONG   biXPelsPerMeter;
	LONG   biYPelsPerMeter;
	DWORD  biClrUsed;
	DWORD  biClrImportant;
} BITMAPINFOHEADER;

typedef struct {
	BYTE	rgbBlue;
	BYTE	rgbGreen;
	BYTE	rgbRed;
	BYTE	rgbReserved;
} RGBQUAD;

typedef struct {
	BITMAPINFOHEADER bmiHeader;
	RGBQUAD          bmiColors[1];
} BITMAPINFO;

