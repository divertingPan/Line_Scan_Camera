#include "integer.h"

#define OLED_X	128
#define OLED_Y	64

extern const BYTE FontSmall[], FontLarge[];


void disp_cls (void);
void disp_init (void);
void disp_locate (WORD, const BYTE*, BYTE*);
void disp_putc (unsigned char);
void disp_put_bat (UINT);
void disp_xfer_image (const BYTE*, BYTE, BYTE, BYTE, BYTE);
void disp_draw_image (const BYTE*, BYTE, BYTE, BYTE*);


#define	IMPORT_BIN(file, sym) asm (\
		".section \".rodata\"\n"\
		".balign 4\n"\
		".global " #sym "\n"\
		#sym ":\n"\
		".incbin \"" file "\"\n"\
		".set _endof_" #sym ", " #sym "\n"\
		".global _endof_" #sym "\n"\
		".balign 4\n"\
		".section \".text\"\n")

#define	IMPORT_BIN_PART(file, ofs, siz, sym) asm (\
		".section \".rodata\"\n"\
		".balign 4\n"\
		".global " #sym "\n"\
		#sym ":\n"\
		".incbin \"" file "\"," #ofs "," #siz "\n"\
		".set _endof_" #sym ", " #sym "\n"\
		".global _endof_" #sym "\n"\
		".balign 4\n"\
		".section \".text\"\n")


